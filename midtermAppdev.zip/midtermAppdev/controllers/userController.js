// controllers/userController.js
const users = require('../models/userModel'); // Import the shared users array

// Register a new user
const registerUser = (req, res) => {
    const { username, password, email } = req.body;

    console.log('Registering User:', { username, password, email });

    // Check if the user already exists
    const existingUser = users.find(user => user.username === username || user.email === email);
    if (existingUser) {
        return res.status(400).send('User already exists');
    }

    // Create a new user
    const newUser = { 
        id: users.length + 1,
        username,
        password,
        email
    };
    
    users.push(newUser); // Add the user to the array

    console.log('Current Users:', users); // Log current users for debugging

    res.status(201).send('User registered successfully');
    req.app.locals.users = users; // Store users in a global app variable
};

// Login a user
const loginUser = (req, res) => {
    const { username, password } = req.body;

    console.log('Login Attempt:', { username, password });

    const user = users.find(user => user.username === username && user.password === password);
    
    if (!user) {
        return res.status(401).send('Invalid username or password');
    }

    const token = `Bearer ${user.id}`; // Token format: Bearer <user_id>
    
    console.log('Login Successful for User:', user.username);

    res.status(200).json({ message: 'Login successful', token });
};

// Get user profile
const getProfile = (req, res) => {
    const userId = req.user.id; // Get user ID from middleware

    const user = users.find(user => user.id === userId);

    if (!user) {
        return res.status(404).send('User not found');
    }

    console.log('Sending Profile Data:', {
        id: user.id,
        username: user.username,
        email: user.email
    });

    res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email
    });
};

module.exports = { registerUser, loginUser, getProfile };
