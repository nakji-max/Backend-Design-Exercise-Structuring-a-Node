const express = require('express');
const userRoutes = require('./routes/user');

const app = express();

// Use the built-in middleware to parse JSON
app.use(express.json());

// Define a root route
app.get('/', (req, res) => {
    res.send('AI will take over my job hurray!!!!!!');
});

// Use the user routes for requests starting with /user
app.use('/user', userRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

// Start the server on port 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
