const users = []; // This will act as an in-memory database

module.exports = users;  // Export the users array