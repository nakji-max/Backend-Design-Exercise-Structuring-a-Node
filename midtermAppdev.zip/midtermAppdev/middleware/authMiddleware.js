// middleware/authMiddleware.js
const users = require('../models/userModel'); // Import the users array

const authMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).send('Authorization token is missing');
    }

    // Extract the token from the header
    const token = authHeader.split(' ')[1]; // This should give you just the user ID part

    // Log the extracted token
    console.log('Extracted Token:', token); // Log the token for debugging

    // Try to parse the token to integer
    const userId = parseInt(token); 

    // Log the user ID for debugging
    console.log('Extracted User ID from Token:', userId); // Log the user ID

    // Check if the userId is a number
    if (isNaN(userId)) {
        return res.status(401).send('Invalid token format');
    }

    // Print the users array
    console.log('Current Users:', users); // Check the users array

    // Find the user based on the user ID
    const user = users.find(user => user.id === userId);
    console.log('User found in Middleware:', user); // Log the found user

    if (!user) {
        return res.status(401).send('User not found');
    }

    req.user = user; // Set the user in req.user
    next(); // Call the next middleware
};

module.exports = authMiddleware;
