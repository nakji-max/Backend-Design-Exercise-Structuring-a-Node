const express = require('express');
const router = express.Router();
const { users, addUser } = require('../models/userModel'); // Import the users array and addUser function
const authMiddleware = require('../middleware/authMiddleware');

// Route for user registration
router.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  // Validate input (e.g., using Joi)

  // Add user to the database
  addUser(username, email, password);

  res.status(201).send('User registered successfully');
});

// Route for user login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Validate input (e.g., using Joi)

  // Find the user in the database
  const user = users.find(user => user.username === username && user.password === password);

  if (!user) {
    return res.status(401).send('Invalid username or password');
  }

  // Generate a token (e.g., using JWT)
  const token = generateToken(user);

  res.status(200).json({ message: 'Login successful', token });
});

// Route for getting user profile
router.get('/profile', authMiddleware, (req, res) => {
  const user = req.user; // Get user from the middleware

  res.status(200).json({
    id: user.id,
    username: user.username,
    email: user.email,
  });
});

module.exports = router;