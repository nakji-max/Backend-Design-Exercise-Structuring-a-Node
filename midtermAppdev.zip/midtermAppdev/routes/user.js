const express = require('express');
const { registerUser, loginUser, getProfile } = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();  // Create an Express router

// Route to handle user registration
router.post('/register', registerUser);

// Route to handle user login
router.post('/login', loginUser);

// Route to handle user profile (requires authentication)
router.get('/profile', authMiddleware, getProfile);

module.exports = router;  // Export the router
